// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Experimental escrow scaffold for local/testnet review only.
/// @dev NOT audited. Do not deploy with real funds without tests and independent review.
contract AgentBridgeEscrow {
    enum Status { None, Funded, Released, Refunded }

    struct Escrow {
        address payer;
        address payee;
        uint256 amount;
        uint64 deadline;
        Status status;
        bytes32 reference;
    }

    uint256 public nextEscrowId = 1;
    mapping(uint256 => Escrow) public escrows;

    event EscrowFunded(uint256 indexed escrowId, address indexed payer, address indexed payee,
        uint256 amount, uint64 deadline, bytes32 reference);
    event EscrowReleased(uint256 indexed escrowId, address indexed payee);
    event EscrowRefunded(uint256 indexed escrowId, address indexed payer);

    error InvalidAddress();
    error InvalidAmount();
    error InvalidDeadline();
    error NotPayer();
    error NotPayee();
    error WrongStatus();
    error TooEarly();
    error TransferFailed();

    function createNative(address payee, uint64 deadline, bytes32 reference)
        external payable returns (uint256 id)
    {
        if (payee == address(0) || payee == msg.sender) revert InvalidAddress();
        if (msg.value == 0) revert InvalidAmount();
        if (deadline <= block.timestamp) revert InvalidDeadline();

        id = nextEscrowId++;
        escrows[id] = Escrow(msg.sender, payee, msg.value, deadline, Status.Funded, reference);
        emit EscrowFunded(id, msg.sender, payee, msg.value, deadline, reference);
    }

    /// @notice Payee claims after service delivery. This MVP does not verify AI output.
    function release(uint256 id) external {
        Escrow storage e = escrows[id];
        if (e.status != Status.Funded) revert WrongStatus();
        if (msg.sender != e.payee) revert NotPayee();
        e.status = Status.Released;
        (bool ok, ) = payable(e.payee).call{value: e.amount}("");
        if (!ok) revert TransferFailed();
        emit EscrowReleased(id, e.payee);
    }

    function refundExpired(uint256 id) external {
        Escrow storage e = escrows[id];
        if (e.status != Status.Funded) revert WrongStatus();
        if (msg.sender != e.payer) revert NotPayer();
        if (block.timestamp <= e.deadline) revert TooEarly();
        e.status = Status.Refunded;
        (bool ok, ) = payable(e.payer).call{value: e.amount}("");
        if (!ok) revert TransferFailed();
        emit EscrowRefunded(id, e.payer);
    }
}
